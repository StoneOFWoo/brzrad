Kontrolni Vezba #2

Title Webstajt-a: Kondezatori

Zadataci:
1. Dati title webstajt-a isti kao sto je stavljeno u title websajt-a,
2. Obojiti pozadinu stranice u #2d2d30 i slova u boju #007acc,
3. Dodati naslov websajt-a u najvecim slovima zaglavlja "Kondezatori",
4. Kopirati sledeci text u paragraf:

Кондензатор је електротехнички елемент који може да сачува енергију у
облику електричног поља. Кондензатор се састоји од две металне плоче
(најчешће израђене од алуминијума) одвојене изолатором (диалектрик).

5. Dodati sliku "Picture1.jpg" sa sirinom 400px i visinom 300px
6. Definisati zaglavlje sa srednjom velicinom i dati naslov "Blok Kondezatori"

7. Zatim definisati novi paragraf i napisati: У зависности од материјала од ког је диалекетрик направљен,
блок кондензаторе делимо на:

8. Definisati novu listu sa numeracijom i dodati u listu:
папирне, кондензаторе са фолијама од пластичних маса, керамичке и лискунске.

9. Definisati novi description tag i unutar tag-a dodati sledece:

1#
Naslov: Папирни кондензотори
Deskripcija:
се састоје од 2 алуминијусмке проводне фолије и
интегрисаног папира. Папир се ставља између две алуминијумске фолије и
све заједно се намота у смотуљак облика ваљка који се затим заштићује
изолационом масом што чини спољашњу изолацију.

Dodati sliku Picture2 ispod ovog

2#
Naslov: Са фолијама од пластичних маса
Deskripcija: 
поступак израде је исти као код папирних кондензатора само
што се за диалектрик користе пластичне масе. Мањи су од папирних
и на свом телу имају исписана слова која нам говоре од којих
материјала су направљене проводне плоче и диалектрик.

Definisiati novu tabelu i napraviti je kao tabela.png
Obavezno napraviti da prvi red sva slova budu podebljana
